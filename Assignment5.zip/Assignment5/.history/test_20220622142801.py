mem_cell = [1, 9, 2, 3, 5, 10, 7, 6, 4, 8]
print(mem_cell)
