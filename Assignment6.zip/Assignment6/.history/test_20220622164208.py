from ctypes import sizeof


mem_cell = [10, 9, 8, 7, 6, 5, 4, 3, 2, 1]
size = 10

t1 = 0
t2 = 0
t3 = 0
a1 = 40

while(True):
    # TLOOP
    t1 = 0
    if(t1 == a1):
        break
